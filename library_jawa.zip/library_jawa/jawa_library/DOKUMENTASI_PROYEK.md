# 📚 DOKUMENTASI PROYEK: PERPUSTAKAAN JAWA

**Tanggal Pembuatan:** 19 Januari 2026  
**Bahasa Pemrograman:** Dart & Flutter  
**Versi Aplikasi:** 1.0.0  
**Status:** Aktif & Berfungsi

---

## 📖 DAFTAR ISI

1. [Ringkasan Proyek](#ringkasan-proyek)
2. [Fitur Utama](#fitur-utama)
3. [Struktur Direktori](#struktur-direktori)
4. [Teknologi & Dependencies](#teknologi--dependencies)
5. [Deskripsi Model Data](#deskripsi-model-data)
6. [Deskripsi Screens](#deskripsi-screens)
7. [Alur Kerja Aplikasi](#alur-kerja-aplikasi)
8. [Koleksi Buku Perpustakaan](#koleksi-buku-perpustakaan)
9. [Sistem Pengguna (User Roles)](#sistem-pengguna-user-roles)
10. [Panduan Penggunaan](#panduan-penggunaan)
11. [Catatan Teknis](#catatan-teknis)

---

## 1. RINGKASAN PROYEK

### 📝 Deskripsi Umum
**Perpustakaan Jawa** adalah aplikasi mobile berbasis Flutter yang dirancang untuk mengelola koleksi buku-buku bersejarah dan sastra Jawa. Aplikasi ini memungkinkan pengguna untuk melihat katalog buku, meminjam buku, dan melacak riwayat peminjaman.

### 🎯 Tujuan Aplikasi
- Menyediakan akses mudah ke koleksi buku-buku Jawa klasik dan tradisional
- Memfasilitasi sistem peminjaman buku yang terorganisir
- Mengelola stok buku dengan efisien melalui berbagai role pengguna
- Mempromosikan pelestarian sastra dan budaya Jawa

### 🌟 Target Pengguna
- **Admin:** Mengelola sistem, menambah/edit buku
- **Manager:** Memantau pengguna dan aktivitas perpustakaan
- **Member:** Meminjam dan melacak buku yang dipinjam

---

## 2. FITUR UTAMA

### ✅ Fitur yang Tersedia

| Fitur | Deskripsi | Akses |
|-------|-----------|-------|
| **Login/Registrasi** | Sistem autentikasi dengan role berbeda | Semua Pengguna |
| **Daftar Buku** | Menampilkan 10 koleksi buku Jawa | Semua Pengguna |
| **Detail Buku** | Melihat informasi lengkap buku (judul, penulis, cerita) | Semua Pengguna |
| **Peminjaman Buku** | Meminjam buku dan otomatis update stok | Member, Admin, Manager |
| **Favorit Buku** | Tandai buku favorit | Member |
| **Riwayat Pinjam** | Melihat history peminjaman buku | Member |
| **Edit Buku (Admin)** | Menambah/mengubah data buku | Admin |
| **Lihat Pengguna (Manager)** | Melihat daftar member terdaftar | Manager |
| **Logout** | Keluar dari akun | Semua Pengguna |

---

## 3. STRUKTUR DIREKTORI

```
jawa_library/
├── lib/
│   ├── main.dart                    # Entry point aplikasi
│   ├── models/
│   │   └── book.dart               # Model data Buku & User
│   └── screens/
│       ├── register_screen.dart     # Halaman Login/Registrasi
│       ├── home_screen.dart         # Halaman Utama (Daftar Buku)
│       ├── detail_screen.dart       # Halaman Detail Buku
│       └── history_screen.dart      # Halaman Riwayat Pinjam
├── pubspec.yaml                     # Konfigurasi dependencies
├── analysis_options.yaml            # Konfigurasi linting
├── android/                         # Folder Android native code
├── ios/                             # Folder iOS native code
├── linux/                           # Folder Linux desktop
├── macos/                           # Folder macOS desktop
├── windows/                         # Folder Windows desktop
├── web/                             # Folder Web platform
└── test/                            # Test files
```

---

## 4. TEKNOLOGI & DEPENDENCIES

### 📦 Framework & Bahasa
- **Framework:** Flutter 3.9.2+
- **Bahasa Pemrograman:** Dart 3.9.2+
- **Target Platforms:** Android, iOS, Web, Windows, macOS, Linux

### 📚 Dependencies
```yaml
dependencies:
  flutter:
    sdk: flutter
  cupertino_icons: ^1.0.8
```

### 🛠️ Dev Dependencies
```yaml
dev_dependencies:
  flutter_test:
    sdk: flutter
  flutter_lints: ^5.0.0
```

**Penjelasan Dependencies:**
- **flutter:** Framework utama untuk UI
- **cupertino_icons:** Library ikon untuk iOS style icons
- **flutter_lints:** Untuk menjaga code quality dan best practices

---

## 5. DESKRIPSI MODEL DATA

### 📄 File: `lib/models/book.dart`

#### **Class: Book**
Model data untuk merepresentasikan sebuah buku dalam perpustakaan.

```dart
class Book {
  final String title;       // Judul buku
  final String author;      // Nama penulis
  final String story;       // Ringkasan/cerita singkat buku
  final String style;       // Genre/gaya sastra (Legenda, Novel Sejarah, dll)
  int stock;                // Jumlah stok buku tersedia
  bool isFavorite;          // Status favorit pengguna (default: false)
}
```

**Properti Penjelasan:**
| Properti | Tipe | Keterangan |
|----------|------|-----------|
| title | String | Judul buku (immutable) |
| author | String | Nama penulis (immutable) |
| story | String | Ringkasan cerita buku (immutable) |
| style | String | Kategori/gaya sastra (immutable) |
| stock | int | Jumlah stok (dapat berubah saat peminjaman) |
| isFavorite | bool | Tandai favorit atau tidak (dapat berubah) |

#### **Global Data: registeredUsers**
List pengguna terdaftar dengan role berbeda:
```dart
List<Map<String, String>> registeredUsers = [
  {'name': 'Admin1', 'pass': 'admin123', 'role': 'Admin'},
  {'name': 'Manager1', 'pass': 'manager123', 'role': 'Manager'},
];
```

#### **Global Data: bookList**
Koleksi 10 buku Jawa yang tersimpan dalam aplikasi (lihat [bagian 8](#8-koleksi-buku-perpustakaan))

#### **Global Data: loanHistory**
List history peminjaman:
```dart
List<String> loanHistory = [];  // Diisi saat user meminjam buku
```

---

## 6. DESKRIPSI SCREENS

### 🔐 **1. RegisterScreen** (`lib/screens/register_screen.dart`)

**Fungsi:** Halaman login dan registrasi pengguna

**Komponen UI:**
- Icon perpustakaan besar (80x80)
- Judul: "Login Perpustakaan"
- TextField Username
- TextField Password (dengan toggle visibility)
- DropdownButton untuk memilih Role (Member/Admin/Manager)
- Button "MASUK / DAFTAR"

**Fitur:**
- ✅ Validasi input (username & password tidak boleh kosong)
- ✅ Login untuk user existing di `registeredUsers`
- ✅ Registrasi otomatis untuk user baru
- ✅ Pilih role saat registrasi (default: Member)
- ✅ Toggle password visibility

**Flow:**
1. User input username & password
2. Pilih role (hanya untuk registrasi baru)
3. Klik "MASUK / DAFTAR"
4. Jika user ada → Login
5. Jika user baru → Registrasi otomatis
6. Navigasi ke HomeScreen dengan role yang dipilih

---

### 🏠 **2. HomeScreen** (`lib/screens/home_screen.dart`)

**Fungsi:** Halaman utama menampilkan daftar semua buku

**Komponen UI:**
- AppBar dengan title menampilkan role dan nama user
- ListView dengan daftar buku dalam bentuk Card
- FloatingActionButton (berbeda sesuai role)
- Tombol History & Logout di AppBar

**Fitur Per Role:**

#### **Member:**
- ✅ Lihat daftar buku
- ✅ Icon favorit untuk tandai buku favorit
- ✅ Tombol History di AppBar
- ✅ AppBar berwarna Brown

#### **Admin:**
- ✅ Lihat daftar buku
- ✅ Icon edit untuk setiap buku
- ✅ FAB "Tambah Buku" (warna merah)
- ✅ AppBar berwarna Merah Tua

#### **Manager:**
- ✅ Lihat daftar buku
- ✅ FAB "Lihat Member" (warna biru)
- ✅ AppBar berwarna Biru Tua

**Fitur Umum:**
- ✅ Klik buku untuk membuka DetailScreen
- ✅ Auto-refresh stok setelah peminjaman
- ✅ Tombol Logout (semua role)

---

### 📖 **3. DetailScreen** (`lib/screens/detail_screen.dart`)

**Fungsi:** Menampilkan informasi detail buku

**Komponen UI:**
- AppBar dengan judul buku
- Judul buku (font besar, bold)
- Penulis buku
- Divider
- Label "Cerita Singkat"
- Text body dengan cerita (scrollable)
- Divider
- Status stok buku
- Button "PINJAM BUKU" atau "STOK HABIS"

**Fitur:**
- ✅ Tampilkan semua informasi buku
- ✅ Button "PINJAM BUKU" aktif jika stok > 0
- ✅ Button disabled dan berubah jadi "STOK HABIS" jika stok = 0
- ✅ Saat meminjam:
  - Stok berkurang 1
  - Tambah entry ke `loanHistory`
  - Tampilkan SnackBar berhasil
  - Kembali ke HomeScreen

---

### 📜 **4. HistoryScreen** (`lib/screens/history_screen.dart`)

**Fungsi:** Menampilkan riwayat peminjaman user

**Komponen UI:**
- AppBar dengan judul "Riwayat Pinjam"
- Jika history kosong:
  - Icon history_toggle_off (60x60)
  - Text "Belum ada riwayat peminjaman"
- Jika ada history:
  - ListView dengan separator divider
  - ListTile dengan:
    - Icon check_circle (hijau)
    - Teks history peminjaman
    - Subtitle "Status: Berhasil dipinjam"

**Fitur:**
- ✅ Tampilkan semua riwayat peminjaman
- ✅ Hanya bisa diakses oleh Member
- ✅ Formatted history: "Pinjam: [Judul Buku] - [Waktu]"

---

## 7. ALUR KERJA APLIKASI

### 📊 User Flow Diagram

```
┌─────────────────────────────────────────────────────────────┐
│                   PERPUSTAKAAN JAWA APP                      │
└─────────────────────────────────────────────────────────────┘
                              ↓
                      [RegisterScreen]
                    (Login / Registrasi)
                              ↓
                    Pilih Role & Input
                    Akun (Username/Pass)
                              ↓
         ┌────────────────────┼────────────────────┐
         ↓                    ↓                    ↓
    [MEMBER]           [ADMIN]              [MANAGER]
    
         ↓                    ↓                    ↓
  ┌─────────────┐      ┌─────────────┐      ┌─────────────┐
  │ HomeScreen  │      │ HomeScreen  │      │ HomeScreen  │
  │ (Brown)     │      │ (Red)       │      │ (Blue)      │
  └─────────────┘      └─────────────┘      └─────────────┘
         ↓                    ↓                    ↓
    • Daftar Buku       • Daftar Buku       • Daftar Buku
    • Favorit           • Edit Buku         • Lihat Member
    • History Button    • Tambah FAB        • Lihat FAB
    
         ↓
  [DetailScreen]
  • Lihat detail buku
  • Pinjam buku
  • Update stok
         ↓
  [HistoryScreen]
  • Lihat riwayat pinjam
  
         ↓
    [Logout]
  • Kembali ke RegisterScreen
```

---

## 8. KOLEKSI BUKU PERPUSTAKAAN

Aplikasi memiliki 10 buku Jawa dengan data lengkap sebagai berikut:

### 📚 Data Buku

| No | Judul | Penulis | Gaya/Genre | Stok | Cerita |
|----|-------|---------|-----------|------|--------|
| 1 | **Serat Centhini** | R.Ng. Rangga Warsita | Sastra Spiritual | 5 | Nyritakake lelampahan Putra-putri Sunan Giri nalika kraton Giri ditalukake dening Mataram. Isine babagan kawruh spiritual, seni, lan urip Jawa. |
| 2 | **Legenda Ajisaka** | Anonim | Legenda | 5 | Kisah pemuda sakti bernama Ajisaka yang mengalahkan raksasa Prabu Dewata Cengkar dan menciptakan aksara Jawa (Hanacaraka). |
| 3 | **Babad Tanah Jawi** | W.L. Olthof | Sejarah | 5 | Kitab sejarah kang dadi babon utama sejarah kraton-kraton ing Jawa, wiwit jaman dewa nganti Mataram Islam. |
| 4 | **Ken Arok & Ken Dedes** | Pramoedya Ananta Toer | Novel Sejarah | 9 | Kisah kraman lan ambisi Ken Arok kanggo dadi raja ing Tumapel nggunakake keris sekti Empu Gandring. |
| 5 | **Dewaruci** | Sunan Kalijaga | Wayang/Filsafat | 8 | Lelampahan Bima nggoleki Banyu Perwitasari lan nemokake wejangan suci saka Dewaruci ing dhasar segara. |
| 6 | **Roro Jonggrang** | Rakyat Yogyakarta | Cerita Rakyat | 10 | Kisah Bandung Bondowoso sing kudu mbangun 1000 candhi ing sakwengi kanggo nggarwa putri Roro Jonggrang. |
| 7 | **Ande-Ande Lumut** | Anonim | Dongeng | 10 | Pangeran sing nggoleki garwane liwat sayembara, ing kono dheweke milih Klenting Kuning sing setya. |
| 8 | **Serat Wedhatama** | Mangkunegara IV | Filsafat | 10 | Ajaran luhur babagan olah rasa lan budi pekerti supaya manungsa Jawa urip kanthi bijaksana. |
| 9 | **Gatoloço** | Anonim | Sastra Satir | 10 | Sastra kritis sing kebak perlambang jero ngenani elmu hakekat lan eksistensi manungsa ing alam dunya. |
| 10 | **Negarakertagama** | Mpu Prapanca | Pujastra Kuno | 10 | Kitab kuno jaman Majapahit sing nggambarake kahanan negara nalika dipimpin Prabu Hayam Wuruk. |

---

## 9. SISTEM PENGGUNA (User Roles)

### 🧑‍💼 **Role: ADMIN**

**Deskripsi:** Administrator perpustakaan dengan akses penuh

**Hak Akses:**
- ✅ Melihat daftar buku
- ✅ Menambah buku baru
- ✅ Edit data buku (judul, penulis, cerita)
- ✅ Menghapus buku
- ✅ Melihat dan mengelola pengguna
- ✅ Mengatur stok buku

**Indikator UI:**
- AppBar warna Merah Tua (Colors.red[900])
- Icon Edit di setiap buku
- FAB Tambah Buku (Merah)

**User Default:**
```
Username: Admin1
Password: admin123
```

---

### 👔 **Role: MANAGER**

**Deskripsi:** Manajer perpustakaan untuk monitoring

**Hak Akses:**
- ✅ Melihat daftar buku
- ✅ Melihat dan monitoring pengguna (Member)
- ✅ Melihat history peminjaman
- ✅ Laporan statistik (future)

**Indikator UI:**
- AppBar warna Biru Tua (Colors.blue[900])
- FAB Lihat Member (Biru)

**User Default:**
```
Username: Manager1
Password: manager123
```

---

### 👤 **Role: MEMBER**

**Deskripsi:** Anggota perpustakaan (user biasa)

**Hak Akses:**
- ✅ Melihat daftar buku
- ✅ Melihat detail buku
- ✅ Meminjam buku
- ✅ Tandai buku favorit
- ✅ Melihat riwayat peminjaman

**Indikator UI:**
- AppBar warna Brown (default)
- Icon Favorite Border untuk tandai favorit
- History Button di AppBar
- Tidak ada FAB (atau FAB null)

**Cara Registrasi:**
- Masuk RegisterScreen
- Input username & password (baru)
- Pilih Role: "Member"
- Klik "MASUK / DAFTAR"

---

## 10. PANDUAN PENGGUNAAN

### 🚀 Cara Menjalankan Aplikasi

#### **1. Prerequisites (Prasyarat)**
```bash
# Pastikan Flutter sudah terinstall
flutter --version

# Update Flutter ke versi terbaru (opsional)
flutter upgrade

# Dapatkan dependencies
cd jawa_library
flutter pub get
```

#### **2. Menjalankan di Android Emulator/Device**
```bash
# List devices yang tersedia
flutter devices

# Run aplikasi
flutter run

# Atau run dengan device tertentu
flutter run -d <device_id>
```

#### **3. Menjalankan di iOS**
```bash
# Run di iOS Simulator
flutter run -d all

# Atau spesifik iPhone
flutter run -d ios
```

#### **4. Menjalankan di Web Browser**
```bash
# Run di web
flutter run -d web-server

# Buka browser ke localhost:5000
```

#### **5. Build APK (Android)**
```bash
flutter build apk --release
# Output: build/app/outputs/flutter-apk/app-release.apk
```

---

### 📱 Panduan Penggunaan User

#### **Untuk User Baru (Registrasi)**
1. Buka aplikasi → Tampil RegisterScreen
2. Input username (unik)
3. Input password (minimal 6 karakter recommended)
4. Pilih Role (Member/Admin/Manager)
5. Klik "MASUK / DAFTAR"
6. Masuk ke HomeScreen

#### **Untuk User Existing (Login)**
1. Input username & password (sudah terdaftar)
2. Klik "MASUK / DAFTAR"
3. Masuk ke HomeScreen dengan role sebelumnya

#### **Meminjam Buku (Member)**
1. Di HomeScreen, lihat daftar buku
2. Klik buku yang ingin dipinjam → DetailScreen
3. Lihat informasi buku dan stok
4. Klik "PINJAM BUKU"
5. Stok berkurang, history terupdate
6. Kembali ke HomeScreen

#### **Lihat Riwayat Pinjam (Member)**
1. Di HomeScreen, klik icon History (di AppBar)
2. Tampil HistoryScreen
3. Lihat semua buku yang sudah dipinjam

#### **Tandai Favorit (Member)**
1. Di HomeScreen, klik icon Heart (favorit_border)
2. Icon berubah jadi Heart (favorit) berwarna merah
3. Buku ditandai sebagai favorit

#### **Lihat Member (Manager)**
1. Di HomeScreen, klik FAB (icon people)
2. Tampil list pengguna terdaftar (future implementation)

---

## 11. CATATAN TEKNIS

### 🔧 Struktur Code

#### **State Management**
Aplikasi menggunakan **setState()** untuk state management (sederhana, cocok untuk aplikasi kecil):
```dart
setState(() {
  book.isFavorite = !book.isFavorite;
  book.stock--;
});
```

#### **Navigation**
Menggunakan **MaterialApp dengan Navigator.push/pushReplacement**:
```dart
Navigator.push(context, MaterialPageRoute(builder: (_) => DetailScreen()));
Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => HomeScreen()));
```

#### **Data Persistence**
Saat ini data disimpan dalam **global variables** di memory:
- `registeredUsers` - List user terdaftar
- `bookList` - Koleksi buku
- `loanHistory` - Riwayat peminjaman

> ⚠️ **Catatan:** Data akan hilang jika aplikasi ditutup. Untuk production, gunakan SharedPreferences atau SQLite.

---

### 🎨 Design & UI

#### **Tema Warna**
- **Primary:** Brown (perpustakaan tradisional)
- **Admin:** Red[900] (otoritas)
- **Manager:** Blue[900] (profesi)
- **Member:** Brown (user biasa)
- **Accent:** Colors.white, Colors.grey

#### **Responsive Design**
- ✅ SingleChildScrollView untuk overflow content
- ✅ Expanded widget untuk flexible layout
- ✅ ListView.builder untuk list yang scalable
- ✅ Card untuk informasi terstruktur

#### **Material Design**
- ✅ Menggunakan Material Design principles
- ✅ AppBar, TextField, ElevatedButton standard
- ✅ Konsisten dengan Flutter guidelines

---

### ⚠️ Limitasi & Future Improvements

#### **Limitasi Saat Ini:**
1. ❌ Data disimpan hanya di memory (hilang saat close)
2. ❌ Tidak ada database backend
3. ❌ Edit/Tambah buku (Admin) belum diimplementasikan
4. ❌ Lihat Member (Manager) belum diimplementasikan
5. ❌ Tidak ada autentikasi aman (plaintext password)
6. ❌ Tidak ada offline mode
7. ❌ Tidak ada image/cover buku

#### **Rekomendasi Pengembangan:**
1. 🔄 Implementasi SQLite/Hive untuk local database
2. 🔄 Backend API dengan Firebase/REST
3. 🔄 Authentication aman (bcrypt/JWT)
4. 🔄 Image upload untuk cover buku
5. 🔄 Search & filter buku
6. 🔄 Notifikasi untuk reminder kembalikan buku
7. 🔄 Export report peminjaman
8. 🔄 Admin dashboard lengkap
9. 🔄 Denda untuk buku yang terlambat
10. 🔄 Rating & review buku

---

### 🐛 Debugging Tips

#### **Jika Error saat Login:**
```
- Pastikan username & password sesuai (case sensitive)
- Jika user baru, pastikan sudah pilih role
- Cek console untuk error message
```

#### **Jika Stok Tidak Update:**
```
- setState() harus dipanggil setelah ubah stock
- Pastikan Navigator.pop() dijalankan setelah pinjam
```

#### **Jika History Kosong:**
```
- Pastikan sudah meminjam buku sebelumnya
- Check loanHistory list di DetailScreen
```

---

### 📞 Support & Contact

Jika ada pertanyaan atau bug report:
- Cek console log untuk error message
- Gunakan Flutter Doctor untuk cek environment
- Baca flutter documentation: https://flutter.dev/docs

---

## 📋 Ringkasan File Kunci

| File | Baris | Fungsi |
|------|-------|--------|
| `main.dart` | 1-21 | Entry point & MaterialApp config |
| `book.dart` | 1-130 | Model & global data (users, books, history) |
| `register_screen.dart` | 1-130 | Login & registrasi UI & logic |
| `home_screen.dart` | 1-157 | Home & daftar buku UI |
| `detail_screen.dart` | 1-80 | Detail buku & peminjaman logic |
| `history_screen.dart` | 1-50 | Riwayat peminjaman UI |

---

## 📊 Statistik Proyek

- **Total Buku:** 10 buah
- **Role Pengguna:** 3 (Admin, Manager, Member)
- **Screens:** 4 (Register, Home, Detail, History)
- **Total Baris Kode:** ~600 lines
- **Dependencies:** 2 main (flutter, cupertino_icons)
- **Supported Platforms:** 6 (Android, iOS, Web, Windows, macOS, Linux)

---

**Dokumentasi Dibuat Oleh:** GitHub Copilot  
**Tanggal:** 19 Januari 2026  
**Versi Dokumentasi:** 1.0

---

### 📝 Catatan Akhir

Dokumentasi ini dibuat berdasarkan analisis mendalam terhadap source code aplikasi Perpustakaan Jawa. Semua fitur, flow, dan struktur telah dijelaskan dengan detail untuk memudahkan maintenance dan development di masa depan.

Selamat menggunakan Perpustakaan Jawa! 📚✨
