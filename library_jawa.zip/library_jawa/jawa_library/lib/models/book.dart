// lib/models/book.dart

class Book {
  final String title;
  final String author;
  final String story;
  final String style; // Kita tambahkan properti style di sini
  int stock;
  bool isFavorite;

  Book({
    required this.title,
    required this.author,
    required this.story,
    required this.style, // Tambahkan di konstruktor
    required this.stock,
    this.isFavorite = false,
  });
}

// Data User (Admin & Manager)
List<Map<String, String>> registeredUsers = [
  {'name': 'Admin1', 'pass': 'admin123', 'role': 'Admin'},
  {'name': 'Manager1', 'pass': 'manager123', 'role': 'Manager'},
];

// Koleksi 10 Buku Jawa Lengkap
List<Book> bookList = [
  Book(
    title: 'Serat Centhini',
    author: 'R.Ng. Rangga Warsita',
    style: 'Sastra Spiritual',
    stock: 5,
    story:
        'Nyritakake lelampahan Putra-putri Sunan Giri nalika kraton Giri ditalukake dening Mataram. Isine babagan kawruh spiritual, seni, lan urip Jawa.',
  ),
  Book(
    title: 'Legenda Ajisaka',
    author: 'Anonim',
    style: 'Legenda',
    stock: 5,
    story:
        'Kisah pemuda sakti bernama Ajisaka yang mengalahkan raksasa Prabu Dewata Cengkar dan menciptakan aksara Jawa (Hanacaraka).',
  ),
  Book(
    title: 'Babad Tanah Jawi',
    author: 'W.L. Olthof',
    style: 'Sejarah',
    stock: 5,
    story:
        'Kitab sejarah kang dadi babon utama sejarah kraton-kraton ing Jawa, wiwit jaman dewa nganti Mataram Islam.',
  ),
  Book(
    title: 'Ken Arok & Ken Dedes',
    author: 'Pramoedya Ananta Toer',
    style: 'Novel Sejarah',
    stock: 9,
    story:
        'Kisah kraman lan ambisi Ken Arok kanggo dadi raja ing Tumapel nggunakake keris sekti Empu Gandring.',
  ),
  Book(
    title: 'Dewaruci',
    author: 'Sunan Kalijaga',
    style: 'Wayang/Filsafat',
    stock: 8,
    story:
        'Lelampahan Bima nggoleki Banyu Perwitasari lan nemokake wejangan suci saka Dewaruci ing dhasar segara.',
  ),
  Book(
    title: 'Roro Jonggrang',
    author: 'Rakyat Yogyakarta',
    style: 'Cerita Rakyat',
    stock: 10,
    story:
        'Kisah Bandung Bondowoso sing kudu mbangun 1000 candhi ing sakwengi kanggo nggarwa putri Roro Jonggrang.',
  ),
  Book(
    title: 'Ande-Ande Lumut',
    author: 'Anonim',
    style: 'Dongeng',
    stock: 10,
    story:
        'Pangeran sing nggoleki garwane liwat sayembara, ing kono dheweke milih Klenting Kuning sing setya.',
  ),
  Book(
    title: 'Serat Wedhatama',
    author: 'Mangkunegara IV',
    style: 'Filsafat',
    stock: 10,
    story:
        'Ajaran luhur babagan olah rasa lan budi pekerti supaya manungsa Jawa urip kanthi bijaksana.',
  ),
  Book(
    title: 'Gatoloço',
    author: 'Anonim',
    style: 'Sastra Satir',
    stock: 10,
    story:
        'Sastra kritis sing kebak perlambang jero ngenani elmu hakekat lan eksistensi manungsa ing alam dunya.',
  ),
  Book(
    title: 'Negarakertagama',
    author: 'Mpu Prapanca',
    style: 'Pujastra Kuno',
    stock: 10,
    story:
        'Kitab kuno jaman Majapahit sing nggambarake kahanan negara nalika dipimpin Prabu Hayam Wuruk.',
  ),
];

List<String> loanHistory = [];
