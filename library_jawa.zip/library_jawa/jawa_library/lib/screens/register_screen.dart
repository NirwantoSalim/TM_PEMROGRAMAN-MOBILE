// lib/screens/register_screen.dart
import 'package:flutter/material.dart';
import '../models/book.dart'; // Jalur import ini harus benar
import 'home_screen.dart';

class RegisterScreen extends StatefulWidget {
  @override
  _RegisterScreenState createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  final TextEditingController nameController = TextEditingController();
  final TextEditingController passController = TextEditingController();
  String selectedRole = 'Member';
  bool _isObscured = true;

  void _handleLogin() {
    String name = nameController.text.trim();
    String pass = passController.text.trim();

    if (name.isEmpty || pass.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Username lan Password kudu diisi!")),
      );
      return;
    }

    // Mencari user di list global registeredUsers
    try {
      var user = registeredUsers.firstWhere(
        (u) => u['name'] == name && u['pass'] == pass,
        orElse: () => {},
      );

      if (user.isNotEmpty) {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (context) =>
                HomeScreen(userName: user['name']!, role: user['role']!),
          ),
        );
      } else {
        // Jika belum ada, daftar otomatis
        registeredUsers.add({'name': name, 'pass': pass, 'role': selectedRole});
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (context) =>
                HomeScreen(userName: name, role: selectedRole),
          ),
        );
      }
    } catch (e) {
      print("Error: $e");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.brown[50],
      body: Center(
        child: SingleChildScrollView(
          padding: EdgeInsets.all(24.0),
          child: Column(
            children: [
              Icon(Icons.account_balance, size: 80, color: Colors.brown[800]),
              SizedBox(height: 20),
              Text(
                "Login Perpustakaan",
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 20),
              TextField(
                controller: nameController,
                decoration: InputDecoration(
                  labelText: 'Username',
                  border: OutlineInputBorder(),
                  filled: true,
                  fillColor: Colors.white,
                ),
              ),
              SizedBox(height: 15),
              TextField(
                controller: passController,
                obscureText: _isObscured,
                decoration: InputDecoration(
                  labelText: 'Password',
                  border: OutlineInputBorder(),
                  filled: true,
                  fillColor: Colors.white,
                  suffixIcon: IconButton(
                    icon: Icon(
                      _isObscured ? Icons.visibility : Icons.visibility_off,
                    ),
                    onPressed: () => setState(() => _isObscured = !_isObscured),
                  ),
                ),
              ),
              SizedBox(height: 15),
              DropdownButtonFormField<String>(
                value: selectedRole,
                decoration: InputDecoration(
                  border: OutlineInputBorder(),
                  labelText: 'Pilih Role (Jika Daftar Baru)',
                  filled: true,
                  fillColor: Colors.white,
                ),
                items: ['Member', 'Admin', 'Manager']
                    .map(
                      (role) =>
                          DropdownMenuItem(value: role, child: Text(role)),
                    )
                    .toList(),
                onChanged: (val) => setState(() => selectedRole = val!),
              ),
              SizedBox(height: 25),
              SizedBox(
                width: double.infinity,
                height: 50,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.brown[800],
                  ),
                  onPressed: _handleLogin,
                  child: Text(
                    'MASUK / DAFTAR',
                    style: TextStyle(color: Colors.white),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
