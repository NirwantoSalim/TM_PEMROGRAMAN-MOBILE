import 'package:flutter/material.dart';
import '../models/book.dart';
import 'detail_screen.dart';
import 'history_screen.dart';
import 'register_screen.dart';

class HomeScreen extends StatefulWidget {
  final String userName;
  final String role;

  // Konstruktor harus menerima userName dan role
  HomeScreen({required this.userName, required this.role});

  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        // Warna AppBar berubah sesuai Role
        backgroundColor: widget.role == 'Admin'
            ? Colors.red[900]
            : (widget.role == 'Manager' ? Colors.blue[900] : Colors.brown),
        title: Text('${widget.role}: ${widget.userName}'),
        actions: [
          // Tombol History hanya untuk Member
          if (widget.role == 'Member')
            IconButton(
              icon: Icon(Icons.history),
              onPressed: () => Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => HistoryScreen()),
              ),
            ),
          // Tombol Log Out
          IconButton(
            icon: Icon(Icons.logout),
            onPressed: () => _showLogoutDialog(context),
          ),
        ],
      ),
      body: ListView.builder(
        itemCount: bookList.length,
        itemBuilder: (context, index) {
          final book = bookList[index];
          return Card(
            margin: EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            child: ListTile(
              leading: Icon(Icons.book, color: Colors.brown),
              title: Text(
                book.title,
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              subtitle: Text("Penulis: ${book.author}\nStok: ${book.stock}"),
              trailing: widget.role == 'Admin'
                  ? Icon(
                      Icons.edit,
                      color: Colors.orange,
                    ) // Indikator Admin bisa edit
                  : IconButton(
                      icon: Icon(
                        book.isFavorite
                            ? Icons.favorite
                            : Icons.favorite_border,
                        color: Colors.red,
                      ),
                      onPressed: () =>
                          setState(() => book.isFavorite = !book.isFavorite),
                    ),
              onTap: () async {
                await Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => DetailScreen(book: book),
                  ),
                );
                setState(() {}); // Refresh stok saat kembali
              },
            ),
          );
        },
      ),
      // Tombol khusus Admin (Tambah) atau Manager (Lihat User)
      floatingActionButton: widget.role == 'Admin'
          ? FloatingActionButton(
              backgroundColor: Colors.red[900],
              child: Icon(Icons.add, color: Colors.white),
              onPressed: () {}, // Tambah buku
            )
          : (widget.role == 'Manager'
                ? FloatingActionButton(
                    backgroundColor: Colors.blue[900],
                    child: Icon(Icons.people, color: Colors.white),
                    onPressed: () => _showMembersList(context),
                  )
                : null),
    );
  }

  void _showLogoutDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text("Log Out"),
        content: Text("Yakin badhe medal (keluar)?"),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text("Batal"),
          ),
          TextButton(
            onPressed: () {
              Navigator.pushAndRemoveUntil(
                context,
                MaterialPageRoute(builder: (context) => RegisterScreen()),
                (route) => false,
              );
            },
            child: Text("Metu", style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }

  void _showMembersList(BuildContext context) {
    showModalBottomSheet(
      context: context,
      builder: (context) => Container(
        padding: EdgeInsets.all(16),
        child: Column(
          children: [
            Text(
              "Daftar Anggota (Manager View)",
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            Divider(),
            Expanded(
              child: ListView.builder(
                itemCount: registeredUsers.length,
                itemBuilder: (context, i) => ListTile(
                  leading: Icon(Icons.person),
                  title: Text(registeredUsers[i]['name']!),
                  subtitle: Text("Role: ${registeredUsers[i]['role']}"),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
