import 'package:flutter/material.dart';
import '../models/book.dart';

class DetailScreen extends StatefulWidget {
  final Book book;
  DetailScreen({required this.book});

  @override
  _DetailScreenState createState() => _DetailScreenState();
}

class _DetailScreenState extends State<DetailScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.brown,
        title: Text(widget.book.title),
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              widget.book.title,
              style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold),
            ),
            Text(
              "Penulis: ${widget.book.author}",
              style: TextStyle(fontSize: 16, color: Colors.grey[700]),
            ),
            Divider(height: 30, thickness: 2),
            Text(
              "Cerita Singkat:",
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 10),
            Expanded(
              child: SingleChildScrollView(
                child: Text(
                  widget.book.story,
                  style: TextStyle(fontSize: 16, height: 1.5),
                  textAlign: TextAlign.justify,
                ),
              ),
            ),
            Divider(),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  "Tersedia: ${widget.book.stock} buku",
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.brown,
                  ),
                  onPressed: widget.book.stock > 0
                      ? () {
                          setState(() {
                            widget.book.stock--;
                            loanHistory.add(
                              "Pinjam: ${widget.book.title} - ${DateTime.now().hour}:${DateTime.now().minute}",
                            );
                          });
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(content: Text('Berhasil meminjam buku!')),
                          );
                          Navigator.pop(context);
                        }
                      : null,
                  child: Text(
                    widget.book.stock > 0 ? 'PINJAM BUKU' : 'STOK HABIS',
                    style: TextStyle(color: Colors.white),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
