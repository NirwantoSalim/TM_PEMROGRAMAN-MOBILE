import 'package:flutter/material.dart';
import '../models/book.dart';

class HistoryScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.brown,
        title: Text('Riwayat Pinjam'),
        // Menambahkan warna teks putih agar kontras dengan background cokelat
        foregroundColor: Colors.white,
      ),
      body: loanHistory.isEmpty
          ? Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.history_toggle_off, size: 60, color: Colors.grey),
                  SizedBox(height: 10),
                  Text(
                    'Belum ada riwayat peminjaman.',
                    style: TextStyle(color: Colors.grey),
                  ),
                ],
              ),
            )
          : ListView.separated(
              padding: EdgeInsets.all(8),
              itemCount: loanHistory.length,
              separatorBuilder: (context, index) =>
                  Divider(height: 1), // Garis pembatas antar item
              itemBuilder: (context, index) {
                return ListTile(
                  leading: Icon(Icons.check_circle, color: Colors.green),
                  title: Text(
                    loanHistory[index],
                    style: TextStyle(fontWeight: FontWeight.w500),
                  ),
                  subtitle: Text("Status: Berhasil dipinjam"),
                );
              },
            ),
    );
  }
}
