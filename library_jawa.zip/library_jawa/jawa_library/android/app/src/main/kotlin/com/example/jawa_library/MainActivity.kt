package com.example.jawa_library

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
